
/* validates that the entry is formatted as an email address */
function Validate(thisForm) {
    var tocheck = thisForm.email.value;
    var re = /^[\w\._-]+@[\w\._-]+\.[a-zA-Z]{2,7}$/;
    if (!tocheck.match(re)) {
        alert("Please verify the email address format.");
        thisForm.email.focus();
        thisForm.email.style.backgroundColor = '#ff9';
        return false;
    } else {
        return true;
    }
}/* 
CSCIS-12, Example: 6.9
    Fundamentals of Web Site Development
    David Heitmeyer
*/