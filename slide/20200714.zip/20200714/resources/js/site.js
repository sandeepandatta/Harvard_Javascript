function gteq (a,b) {
    return a >= b;
}